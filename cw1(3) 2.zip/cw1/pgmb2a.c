#include <stdio.h>
#include <stdlib.h>

#define EXIT_NO_ERRORS 0
#define EXIT_WRONG_ARG_COUNT 1
#define EXIT_BAD_FILE_NAME 2
#define EXIT_BAD_MAGIC_NUMBER 3
#define EXIT_BAD_OUTPUT_FILE 4

// 将P5格式的PGM文件转换为P2格式
int p5_to_p2(const char *input_filename, const char *output_filename) {
    FILE *input_file = fopen(input_filename, "rb");
    if (input_file == NULL) {
	printf("ERROR: Bad File Name %s\n", input_filename);
        return EXIT_BAD_FILE_NAME;
    }

    // Read the PGM header
    char magic_number[3];
    int width = 0, height = 0, max_value = 0;
    fscanf(input_file, "%2s\n%d %d\n%d\n", magic_number, &width, &height, &max_value);

    // Check if the input file is a P5 PGM file
    if (magic_number[0] != 'P' || magic_number[1] != '5') {
        fclose(input_file);
	printf("ERROR: Bad Magic Number %s",input_filename);
        return EXIT_BAD_MAGIC_NUMBER;
    }

    FILE *output_file = fopen(output_filename, "w");
    if (output_file == NULL) {
        fclose(output_file);
	printf("ERROR: Output Failed %s",output_filename);
        return EXIT_BAD_OUTPUT_FILE;
    }

    // Write the PGM header to the output file
    fprintf(output_file, "P2\n%d %d\n%d\n", width, height, max_value);

    // Convert the input file from binary to ASCII
    int pixel;
    int len = 1;
    while ((pixel = fgetc(input_file)) != EOF) {
        fprintf(output_file, "%d ", pixel);
        if (len % width == 0) {
            fprintf(output_file, "\n");
        }
        len++;
    }

    // Close the input and output files
    fclose(input_file);
    fclose(output_file);
    printf("CONVERTED");
    return 0;
}

int main(int argc, char *argv[]) {
 // 检查命令行参数数量是否正确
    if (argc == 1) {
        printf("Usage: %s inputImage.pgm outputImage.pgm\n", argv[0]);
        return EXIT_NO_ERRORS;
    }else if(argc !=3)
    {
	printf("ERROR: Bad Argument Count\n");
	return EXIT_WRONG_ARG_COUNT;
     }

    // 调用p5_to_p2函数进行转换
    p5_to_p2(argv[1], argv[2]);
    return 0;
}

