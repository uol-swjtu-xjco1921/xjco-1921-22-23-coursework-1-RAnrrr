#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define EXIT_NO_ERRORS 0
#define EXIT_WRONG_ARG_COUNT 1
#define EXIT_BAD_FILE_NAME 2
#define EXIT_BAD_MAGIC_NUMBER 3
#define EXIT_BAD_COMMENT_LINE 4
#define EXIT_BAD_DIMENSIONS 5
#define EXIT_BAD_MAX_GRAY_VALUE 6
#define EXIT_IMAGE_MALLOC_FAILED 7
#define EXIT_BAD_DATA 8
#define EXIT_OUTPUT_FAILED 9
#define EXIT_MISC_ERROR 100

// 读取ASCII格式的像素值
int read_ascii_value(FILE *fp)
{
    int val = 0;
    char c;
    do
    {
        c = fgetc(fp);
    } while (isspace(c));// 跳过空格字符

    while (isdigit(c)) // 读取连续的数字字符并转换为整数值
    {
        val = val * 10 + c - '0';
        c = fgetc(fp);
    }
    return val;
}
// 读取二进制格式的像素值
int read_binary_value(FILE *fp, int maxval)
{
    int val;
    if (maxval <= 255)// 如果灰度最大值小于等于255，则每个像素值占用一个字节
    {
        val = fgetc(fp);
    }
    else
    {
        val = fgetc(fp) << 8 | fgetc(fp);
    }
    return val;
}


// 写入P5格式的PGM文件头信息
int write_p5_header(FILE *output_file, int width, int height, int max_value) {
    // Write the PGM header to the output file
    if (fprintf(output_file, "P5\n%d %d\n%d\n", width, height, max_value) < 0) {
	return EXIT_OUTPUT_FAILED;
    }
    return 0;
}
// 将P2格式的PGM文件转换为P5格式
int pgmP2toP5(const char *input_filename, const char *output_filename) {
    FILE *input_file = fopen(input_filename, "rb");
    if (input_file == NULL) {
	printf("ERROR: Bad File Name %s",input_filename);
        return EXIT_BAD_FILE_NAME;
    }

    // Read the PGM header
    char magic_number[5];
    int width = 0, height = 0, max_value = 0;
    if (fscanf(input_file, "%2s\n%d %d\n%d\n", magic_number, &width, &height, &max_value) != 4) {
        fclose(input_file);
	printf("ERROR: Bad Magic Number %s",input_filename);
        return EXIT_BAD_MAGIC_NUMBER;
    }

    // Check if the input file is a P2 PGM file
    if (strcmp(magic_number, "P2") != 0) {
        fclose(input_file);
	printf("ERROR: Bad Magic Number %s",input_filename);
        return EXIT_BAD_MAGIC_NUMBER;
    }

    FILE *output_file = fopen(output_filename, "wb");
    if (output_file == NULL) {
        fclose(output_file);
	printf("ERROR: Output Failed %s",output_filename);
        return EXIT_BAD_FILE_NAME;
    }
    // 写入P5格式的PGM文件头信息
    int write_header_result = write_p5_header(output_file, width, height, max_value);
    if (write_header_result != 0) {
        fclose(input_file);
        fclose(output_file);
        return write_header_result;
    }

    int pixel;
    while (fscanf(input_file, "%d", &pixel) == 1) {
     // 将ASCII格式的像素值转换为二进制格式并写入输出文件
        if (fputc((unsigned char)pixel, output_file) == EOF) {
            fclose(input_file);
            fclose(output_file);
            return EXIT_OUTPUT_FAILED;
        }
    }

    fclose(input_file);
    fclose(output_file);
    printf("CONVERTED");
    return 0;
}

int main(int argc, char *argv[]) {
    // Open the input file in read mode
    if (argc == 1) {
         printf("Usage: %s inputImage.pgm outputImage.pgm\n", argv[0]);
        return EXIT_NO_ERRORS;
    }else if(argc !=3)
    {
	printf("ERROR: Bad Argument Count\n");
	return EXIT_WRONG_ARG_COUNT;
     }

    // 调用pgmP2toP5函数进行转换
    int num=pgmP2toP5(argv[1], argv[2]);
    return num;
}

