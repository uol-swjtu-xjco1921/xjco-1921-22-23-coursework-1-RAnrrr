#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINE_LEN 1024
#define EXIT_WRONG_ARG_COUNT 1
#define EXIT_BAD_INPUT_FILE 2
#define EXIT_NO_ERRORS 0

// 从ASCII文件中读取像素值
int read_ascii_value(FILE *fp)
{
    int val = 0;
    char c;
    do
    {
        c = fgetc(fp);
    } while (isspace(c));

    while (isdigit(c))
    {
        val = val * 10 + c - '0';
        c = fgetc(fp);
    }
    return val;
}

// 从二进制文件中读取像素值
int read_binary_value(FILE *fp, int maxval)
{
    int val;
    if (maxval <= 255)
    {
        val = fgetc(fp);
    }
    else
    {
        val = fgetc(fp) << 8 | fgetc(fp);
    }
    return val;
}
// 比较两个PGM文件的像素值是否相同
int comparePGMFiles(char *filename1, char *filename2)
{
    FILE *fp1, *fp2;
    char line1[MAX_LINE_LEN], line2[MAX_LINE_LEN];
    int width1, height1, maxval1, width2, height2, maxval2;
    int x, y, val1, val2, ascii1, ascii2;

    // Open input files
    fp1 = fopen(filename1, "rb");
    if (fp1 == NULL)
    {
        //fprintf(stderr, "Error: cannot open file %s\n", filename1);
	printf("ERROR: Bad File Name %s\n",filename1);
        return EXIT_BAD_INPUT_FILE;
    }
    fp2 = fopen(filename2, "rb");
    if (fp2 == NULL)
    {
        //fprintf(stderr, "Error: cannot open file %s\n", filename2);
	printf("ERROR: Bad File Name %s\n",filename2);
        fclose(fp1);
        return EXIT_BAD_INPUT_FILE;
    }

    // Read and compare header information
    fgets(line1, MAX_LINE_LEN, fp1);
    fgets(line2, MAX_LINE_LEN, fp2);
    // 检查文件头是否匹配
    if (strcmp(line1, line2) != 0)
    {
        //fprintf(stderr, "Error: file headers do not match\n");
	printf("DIFFERENT ");
        fclose(fp1);
        fclose(fp2);
        return 0;
    }
    // 解析文件头信息
    if (strcmp(line1, "P2\n") == 0 || strcmp(line1, "P5\n") == 0)
    {
        ascii1 = 1;
        fscanf(fp1, "%d %d %d", &width1, &height1, &maxval1);
    }
    else if (strcmp(line1, "P3\n") == 0 || strcmp(line1, "P6\n") == 0)
    {
        ascii1 = 0;
        fscanf(fp1, "%d %d %d", &width1, &height1, &maxval1);
    }
    else
    {
        printf("ERROR: Bad Magic Number %s\n", filename1);
        fclose(fp1);
        fclose(fp2);
        return 3;
    }

    if (strcmp(line2, "P2\n") == 0 || strcmp(line2, "P5\n") == 0)
    {
        ascii2 = 1;
        fscanf(fp2, "%d %d %d", &width2, &height2, &maxval2);
    }
    else if (strcmp(line2, "P3\n") == 0 || strcmp(line2, "P6\n") == 0)
    {
        ascii2 = 0;
        fscanf(fp2, "%d", &maxval2);
    }
    else
    {
        printf("ERROR: Bad Magic Number %s\n", filename2);
        fclose(fp1);
        fclose(fp2);
        return 3;
    }
    // 检查尺寸和最大值是否匹配
    if (width1 != width2 || height1 != height2 || maxval1 != maxval2)
    {
        //fprintf(stderr, "Error: file dimensions or maxval do not match\n");
	printf("DIFFERENT ");
        fclose(fp1);
        fclose(fp2);
        return 100;
    }

    // Read and compare pixel values
    for (y = 0; y < height1; y++)
    {
        for (x = 0; x < width1; x++)
        {
            if (ascii1)
            {
                val1 = read_ascii_value(fp1);
            }
            else
            {
                val1 = read_binary_value(fp1, maxval1);
            }

            if (ascii2)
            {
                val2 = read_ascii_value(fp2);
            }
            else
            {
                val2 = read_binary_value(fp2, maxval2);
            }
            // 检查像素值是否匹配
            if (val1 != val2)
            {
                //fprintf(stderr, "Error: pixel (%d,%d) does not match (%d vs %d)\n", x, y, val1, val2);
   		printf("DIFFERENT ");
                fclose(fp1);
                fclose(fp2);
                return 0;
            }
        }
    }

    // Files are identical
    //printf("Files %s and %s are identical.\n", filename1, filename2);
    printf("IDENTICAL ");
    fclose(fp1);
    fclose(fp2);
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc == 1)
    {
        printf("Usage: %s inputImage.pgm inputImage.pgm\n", argv[0]);
        return EXIT_NO_ERRORS;
    }else if(argc !=3)
    {
	printf("ERROR: Bad Argument Count\n");
	return EXIT_WRONG_ARG_COUNT;
     }


    int result = comparePGMFiles(argv[1], argv[2]);

    return result;
}

