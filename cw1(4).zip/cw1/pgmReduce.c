#include<stdio.h>
#define EXIT_NO_ERRORS 0
#define EXIT_WRONG_ARG_COUNT 1
#define EXIT_BAD_INPUT_FILE 2
#define EXIT_Image_Malloc_Failed  7
#define EXIT_BAD_DATA 8
#define EXIT_BAD_OUTPUT_FILE 9

// 减小PGM图像的函数
int imgeReduce(int argc,char *argv[])
{
	char magic_number[3];// PGM文件的魔术数字
    int height;// 图像高度
    int width;// 图像宽度
    int max_gray_value;// 图像最大灰度值
    int i,j;// 循环变量
    int n=atoi(argv[2]);// 缩小倍数
    printf("n=%d\n",n);
    FILE *input_file = fopen(argv[1], "r");// 打开输入文件
    if (!input_file)
    {

        printf("ERROR: Bad File Name %s\n", argv[1]);
        return EXIT_BAD_INPUT_FILE;// 无法打开输入文件
    }
    // 读取PGM文件头信息
    fscanf(input_file, "%s\n%d %d\n%d\n",magic_number, &width, &height, &max_gray_value);
    // 计算缩小后的图像尺寸
    int y=width/n+((width%n >0) ? 1:0);
    int x=height/n+((height%n >0) ? 1:0);
    // 创建输出文件
    FILE *output_file = fopen(argv[3], "wb");
    if (!output_file)
    {
        printf("ERROR: Output Failed %s\n", argv[3]);
        return EXIT_BAD_OUTPUT_FILE;// 无法打开输出文件
    }
    // 读取像素数据
    if (strcmp(magic_number, "P2") == 0)    // P2格式
    {
        int pixels[height][width];// 存储像素值的数组
        if (!pixels)
        {
            return EXIT_BAD_DATA;// 内存分配失败
        }
        int pixel;
        for(int i=0; i<height; i++)
        {
            char str[100];
            for (int j = 0; j < width; j++)
            {
                fscanf(input_file, "%d", &pixel);// 读取像素值
                pixels[i][j] =pixel;// 存储到数组中
            }
            fgets(str,100,input_file);// 读取并忽略一行数据
        }
        int width_len;
        int height_len=0;
	// 写入缩小后的图像的头信息
        fprintf(output_file,"%s\n%d %d\n%d\n",magic_number,y,x,max_gray_value);
        // 将像素值写入输出文件
	for(int i=0; i<y; i++)
        {
            width_len=0;
            for (int j = 0; j < x; j++)
            {
                fprintf(output_file, "%d ", pixels[height_len][width_len]);// 写入像素值
                width_len+=n; // 更新列索引
            }
            height_len+=n;// 更新行索引
            fprintf(output_file,"\n");// 写入换行符
        }
    }
    else if(strcmp(magic_number, "P5") == 0)
    {
	// 写入缩小后的图像的头信息
        fprintf(output_file,"%s\n%d %d\n%d\n",magic_number,y,x,max_gray_value);
        int row_size = width;
        int buf_size = row_size * sizeof(unsigned char);
	// 用于存储一行数据的缓冲区
        unsigned char *row_data = (unsigned char *) malloc(buf_size);
        int row_datas[height][width];// 存储像素值的数组
	// 读取像素数据
        for (int i = 0; i < height; i++)
        {
            size_t count = fread(row_data, sizeof(unsigned char), row_size, input_file);// 读取一行数据
            if (count != row_size)
            {
                printf("ERROR: Bad Data %s\n", argv[1]);
                free(row_data);
                fclose(input_file);
                return EXIT_BAD_INPUT_FILE;// 文件读取错误
            }

            for(j=0; j<row_size; j++)
                row_datas[i][j]=row_data[j];// 将数据存储到数组中
        }
        int width_len,height_len=0;
        for(i=0; i<y; i++)
        {
            width_len=0;
            for(j=0; j<x; j++)
            {
                fwrite(&row_datas[height_len][width_len], sizeof(int), 1, output_file);// 写入像素值
                width_len+=n;// 更新列索引
            }
            height_len+=n;// 更新行索引
        }
        free(row_data);
    }
    fclose(input_file);
    fclose(output_file);
    printf("REDUCED");
    return EXIT_NO_ERRORS;// 返回没有错误
}


int main(int argc ,char *argv[])
{
    if(argc == 1)
	{
		printf("Usage: %s inputImage.pgm reduction_factor outputImage.pgm \n", argv[0]);
		return EXIT_NO_ERRORS;// 参数个数错误
	}else if(argc !=4)
    {
	printf("ERROR: Bad Argument Count\n");
	return EXIT_WRONG_ARG_COUNT;
     }

    return imgeReduce(argc,argv);
}

