#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define EXIT_NO_ERRORS 0
#define EXIT_WRONG_ARG_COUNT 1
#define EXIT_BAD_INPUT_FILE 2
#define EXIT_Bad_Magic_Number 3
#define EXIT_Bad_Dimensions 5
#define EXIT_Bad_Max_Gray_Value 6
#define EXIT_Image_Malloc_Failed 7
#define EXIT_BAD_DATA 8
#define EXIT_BAD_OUTPUT_FILE 9

/**
 * 处理PGM图像文件的函数。
 *
 * @param inputFilename 输入的PGM文件名。
 * @param outputFilename 输出的PGM文件名。
 * @return 表示成功或错误的退出代码。
 */

int pgmImageProcessing(char *inputFilename, char *outputFilename)
{
    int ch;
    FILE *input_file = fopen(inputFilename, "r");
    if (!input_file)
    {
        printf("ERROR: Bad File Name %s\n", inputFilename);
        return EXIT_BAD_INPUT_FILE;
    }

    // 读取PGM文件头信息
    char magic_number[3];
    char str[100];
    int width, height, max_value;
    fscanf(input_file, "%2s", magic_number);// 读取魔术数（P2或P5）
    if (strcmp(magic_number, "P2") == 0)
    {
        fgets(str, 100, input_file);// 忽略可能存在的注释行
        fgets(str, 100, input_file);// 读取图像宽度和高度
    }
    fscanf(input_file, "%d %d\n%d", &width, &height, &max_value);

    // 分配内存以存储像素数据
    int num_pixels = width * height;
    unsigned char *pixels = (unsigned char *)malloc(num_pixels);
    if (!pixels)
    {
	printf("ERROR: Image Malloc Failed");
        return EXIT_Image_Malloc_Failed;
    }

    // 读取像素数据
    if (strcmp(magic_number, "P2") == 0) // P2格式
    {
        int pixel;
        for (int i = 0; i < num_pixels; i++)
        {
            fscanf(input_file, "%d", &pixel);// 读取像素值
            if (pixel < 0 || pixel > 255)
		printf("ERROR: Bad Max Gray Value %s",inputFilename);
                return EXIT_Bad_Max_Gray_Value;// 检查像素值是否有效
            pixels[i] = (unsigned char)pixel;// 将像素值存储到数组中
        }
    }
    else if (strcmp(magic_number, "P5") == 0) // P5格式
    {
        unsigned char byte;
        int read_count = 0;
        while (read_count < num_pixels)
        {
            if (fread(&byte, 1, 1, input_file) != 1)
            {
                return EXIT_BAD_DATA;// 检查读取是否成功
            }
            read_count++;
        }
    }
    else
    {
	printf("ERROR: Bad Magic Number %s",inputFilename);
        return EXIT_Bad_Magic_Number;// 无效的魔术数
    }
    fclose(input_file);

    FILE *output_file = fopen(outputFilename, "w");
    if (!output_file)
    {
        printf("ERROR: Output Failed %s\n", outputFilename);
        return EXIT_BAD_OUTPUT_FILE;
    }

    if (strcmp(magic_number, "P5") == 0)
    {
        FILE *input_file = fopen(inputFilename, "r");
        while ((ch = fgetc(input_file)) != EOF)
        {
            fputc(ch, output_file);// 直接复制二进制数据
        }
        fclose(output_file);
        fclose(input_file);
    }
    else if (strcmp(magic_number, "P2") == 0)
    {
        fprintf(output_file, "%s\n%d %d\n%d\n", magic_number, width, height, max_value);
        for (int i = 0; i < num_pixels; i++)
        {
            if (i % width == 0 && i > 0)
            {
                fprintf(output_file, "\n"); // 在每行末尾添加换行符
            }
            fprintf(output_file, "%d ", pixels[i]);// 写入像素值
        }
        fprintf(output_file, "\n"); // 在文件末尾添加换行符
        fclose(output_file);
    }

    free(pixels);// 释放分配的内存
    printf("ECHOED");
    return EXIT_NO_ERRORS;
}

int main(int argc, char *argv[])
{
    if (argc ==1)
    {
        printf("Usage: %s inputImage.pgm outputImage.pgm\n", argv[0]);
        return EXIT_NO_ERRORS;
    }else if(argc !=3)
    {
	printf("ERROR: Bad Argument Count\n");
	return EXIT_WRONG_ARG_COUNT;
     }

    int result = pgmImageProcessing(argv[1], argv[2]);// 调用图像处理函数

    return result;
}

